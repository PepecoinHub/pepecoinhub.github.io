from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import json, zipfile, math
root=Path('/mnt/data/Frogageddon_Arsenal_Phase1_v10')
for p in ['icons_128','hud_64','effects','previews','docs','sources']:(root/p).mkdir(parents=True,exist_ok=True)
INK='#17212d'; BLACK='#0f151c'; HIGHLIGHT='#ffed83'; GOLD='#fbb82b'; GOLD_DARK='#9b5c12'; GOLD_MID='#d58b13'; PEPE='#70b74b'; PEPE_DARK='#346c3d'; GREEN_HI='#a4d76b'; STEEL='#74818c'; STEEL_HI='#bac3c7'; STEEL_DARK='#3a4b58'; RED='#e84a41'; ORANGE='#ff9f34'; WHITE='#fff9df'; BLUE='#3266a0'; BROWN='#945b32'; PURPLE='#8c71b5'

def new():
 im=Image.new('RGBA',(64,64),(0,0,0,0));return im,ImageDraw.Draw(im)
def poly(d,points,fill,outline=INK,width=2): d.polygon(points,fill=fill);d.line(points+[points[0]],fill=outline,width=width,joint='curve')
def ell(d,box,fill,outline=INK,width=2): d.ellipse(box,fill=fill,outline=outline,width=width)
def line(d,coords,fill=INK,width=2): d.line(coords,fill=fill,width=width,joint='curve')
def sparkle(d,x,y,c=HIGHLIGHT,k=4):
 line(d,[(x-k,y),(x+k,y)],c,2);line(d,[(x,y-k),(x,y+k)],c,2);d.point((x,y),fill=WHITE)
def textpixel(d,pt,s,color=WHITE): d.text(pt,s,font=ImageFont.load_default(),fill=color,stroke_width=0)
def save64(name,im):
 # Authoritative pixel palette, no antialiased text colors.
 from PIL import ImageColor
 pal=[INK,BLACK,HIGHLIGHT,GOLD,GOLD_DARK,GOLD_MID,PEPE,PEPE_DARK,GREEN_HI,STEEL,STEEL_HI,STEEL_DARK,RED,ORANGE,WHITE,BLUE,BROWN,PURPLE,'#d3c1a2','#d79749','#b9722f','#efc487','#4d718b','#99e2ef','#d58d9b','#bfcbd6','#e0ab6a','#fce16b','#ffe465','#594438','#d79d5f','#a4d6f5','#ffaaa2','#f9d373']
 rgbs=[ImageColor.getrgb(c) for c in pal]
 cache={}
 def snap(p):
  if p[3]<128:return (0,0,0,0)
  key=p[:3]
  if key not in cache:cache[key]=min(rgbs,key=lambda q:sum((q[i]-key[i])**2 for i in range(3)))+(255,)
  return cache[key]
 im.putdata([snap(px) for px in im.getdata()])
 im=im.resize((128,128),Image.Resampling.NEAREST)
 im.save(root/'icons_128'/f'{name}.png')
 im.resize((64,64),Image.Resampling.NEAREST).save(root/'hud_64'/f'{name}.png')
 return im

def golden_foot():
 im,d=new()
 # bold, recognizable five toes, large heel and arch, reflective gold
 for (x,y,rx,ry) in [(16,17,8,9),(29,11,7,9),(41,12,6,8),(49,19,5,7),(53,29,4,6)]:
  ell(d,(x-rx,y-ry,x+rx,y+ry),GOLD_MID,INK,2)
  ell(d,(x-rx+2,y-ry+1,x+rx-3,y+ry-3),GOLD,outline=None,width=1)
  d.rectangle((x-rx+4,y-ry+2,x-rx+6,y-ry+4),fill=HIGHLIGHT)
 sole=[(15,24),(23,19),(33,20),(43,27),(45,35),(39,43),(36,51),(30,55),(20,55),(13,49),(10,40),(10,32)]
 poly(d,sole,GOLD_MID,INK,3)
 poly(d,[(17,27),(24,23),(31,25),(39,31),(40,36),(34,40),(31,47),(27,51),(20,50),(15,44),(14,34)],GOLD,outline=None,width=1)
 line(d,[(18,31),(16,40),(20,46)],HIGHLIGHT,3)
 line(d,[(32,28),(36,33),(35,38)],'#ffe465',3)
 line(d,[(15,50),(21,54),(30,53)],GOLD_DARK,2)
 sparkle(d,56,7);sparkle(d,6,57,'#fff2a2',3)
 return im

def bell_bomb():
 im,d=new()
 # fuse, spark, bell tongue, thick brass bell silhouette
 line(d,[(36,14),(39,7),(47,5)],'#594438',3)
 ell(d,(44,1,49,6),ORANGE,RED,1);sparkle(d,50,5,HIGHLIGHT,4)
 ell(d,(26,9,36,17),GOLD_MID,INK,2)
 poly(d,[(23,15),(36,14),(44,23),(47,35),(51,42),(54,45),(51,51),(12,52),(9,46),(14,41),(16,27)],GOLD_MID,INK,3)
 poly(d,[(24,20),(34,18),(40,26),(43,38),(48,45),(14,46),(19,38),(19,27)],GOLD,outline=None,width=1)
 line(d,[(21,28),(26,20),(31,20)],HIGHLIGHT,3)
 line(d,[(17,41),(15,45),(47,45)],'#fce16b',2)
 ell(d,(27,50,38,58),GOLD_DARK,INK,2)
 ell(d,(30,51,36,55),GOLD,outline=None)
 poly(d,[(10,46),(53,46),(54,50),(51,54),(10,54),(7,50)],GOLD_DARK,INK,2)
 line(d,[(14,49),(47,49)],HIGHLIGHT,3)
 textpixel(d,(27,31),'B',INK)
 return im

def frog_mine():
 im,d=new()
 # feet beneath sphere / anti-tamper ring
 ell(d,(6,43,58,57),STEEL_DARK,INK,3)
 for x in range(12,54,8): d.rectangle((x,48,x+4,52),fill=STEEL)
 ell(d,(11,24,53,50),PEPE_DARK,INK,3)
 ell(d,(14,26,49,46),PEPE,outline=None)
 # eyes bulging above face
 ell(d,(18,13,33,33),PEPE_DARK,INK,2);ell(d,(35,13,50,33),PEPE_DARK,INK,2)
 ell(d,(20,17,32,29),WHITE,INK,1);ell(d,(36,17,48,29),WHITE,INK,1)
 ell(d,(27,22,30,26),BLACK,outline=None);ell(d,(39,22,42,26),BLACK,outline=None)
 line(d,[(19,37),(26,41),(38,41),(46,37)],INK,2)
 line(d,[(24,45),(40,45)],GREEN_HI,2)
 # arming light on head, with brass socket
 d.rectangle((31,6,37,16),fill=STEEL_DARK);ell(d,(29,3,39,14),RED,INK,2)
 ell(d,(31,4,35,8),'#ffaaa2',outline=None)
 sparkle(d,51,9,ORANGE,3)
 return im

def moon_rocket():
 im,d=new()
 # angled rocket left-bottom to upper-right
 poly(d,[(13,44),(29,19),(47,10),(53,13),(56,20),(49,39),(25,51)],WHITE,INK,3)
 poly(d,[(39,15),(47,10),(53,13),(56,20),(49,25)],RED,INK,2)
 poly(d,[(17,39),(6,47),(18,46),(21,52),(26,42)],PEPE,INK,2)
 poly(d,[(32,47),(39,55),(44,48),(44,36)],PEPE_DARK,INK,2)
 ell(d,(33,23,45,35),PEPE,INK,2);textpixel(d,(36,24),'P',WHITE)
 poly(d,[(15,48),(7,56),(18,54),(20,51)],ORANGE,RED,2)
 sparkle(d,53,6,WHITE,3)
 return im

def ban_hammer():
 im,d=new()
 # wood handle diagonal, solid chunky gold hammer BAN
 poly(d,[(19,53),(24,56),(42,23),(36,20)],BROWN,INK,3)
 line(d,[(24,50),(37,27)],'#d79d5f',2)
 poly(d,[(10,10),(44,12),(52,19),(48,32),(13,29),(8,22)],GOLD_MID,INK,3)
 poly(d,[(14,13),(42,15),(47,20),(44,27),(14,25)],GOLD,outline=None)
 line(d,[(14,18),(39,18)],HIGHLIGHT,2)
 textpixel(d,(20,17),'BAN',INK)
 sparkle(d,49,8,ORANGE,3)
 return im

def pep_rain():
 im,d=new()
 coins=[(15,34,10),(44,14,11),(47,47,11)]
 for x,y,r in coins:
  ell(d,(x-r,y-r,x+r,y+r),GOLD_MID,INK,2)
  ell(d,(x-r+3,y-r+3,x+r-3,y+r-3),PEPE_DARK,outline=GOLD,width=2)
  textpixel(d,(x-3,y-5),'P',WHITE)
 for sx,sy in [(8,5),(24,3),(37,29),(20,50)]:line(d,[(sx+8,sy-2),(sx-2,sy+10)],'#a4d6f5',2)
 return im

def doge_flyer():
 im,d=new()
 # shiba head with pilot cap, goggles, ears and cape
 poly(d,[(14,31),(5,18),(25,26),(37,26),(51,34),(47,41),(28,48)],RED,INK,2)
 poly(d,[(21,30),(17,9),(30,20),(46,11),(49,31)],'#b9722f',INK,3)
 ell(d,(15,22,52,50),'#d79749',INK,3)
 poly(d,[(36,36),(54,38),(48,47),(36,45)],'#efc487',INK,2)
 ell(d,(44,36,50,41),BLACK,outline=None)
 ell(d,(20,25,33,36),'#4d718b',INK,2);ell(d,(33,25,46,36),'#4d718b',INK,2)
 d.rectangle((20,29,28,31),fill='#99e2ef');d.rectangle((34,29,42,31),fill='#99e2ef')
 line(d,[(19,25),(42,25)],'#d3c1a2',3)
 # tail and jet flames
 poly(d,[(13,38),(6,42),(11,49),(18,43)],'#e0ab6a',INK,2)
 poly(d,[(6,39),(1,43),(7,46)],ORANGE,RED,1)
 return im

def silver_donkey():
 im,d=new()
 # donkey face with two long pointed ears, metallic bomb-shaped head
 poly(d,[(18,27),(13,5),(24,7),(30,23),(35,24),(43,4),(51,8),(47,34)],STEEL,INK,3)
 poly(d,[(17,10),(19,24),(24,25),(21,11)],'#d58d9b',outline=None)
 poly(d,[(44,10),(38,24),(42,25),(47,11)],'#d58d9b',outline=None)
 ell(d,(13,22,53,51),STEEL,INK,3)
 poly(d,[(15,37),(20,30),(47,30),(51,38),(45,47),(22,46)],STEEL_HI,outline=None)
 ell(d,(21,33,26,39),BLACK,outline=None);ell(d,(39,33,44,39),BLACK,outline=None)
 ell(d,(24,44,47,56),STEEL_DARK,INK,2)
 ell(d,(30,46,33,49),BLACK,outline=None);ell(d,(39,46,42,49),BLACK,outline=None)
 # L instead of brand exact mark
 textpixel(d,(32,48),'L',WHITE)
 line(d,[(7,14),(8,23)],'#bfcbd6',2);line(d,[(56,8),(56,24)],'#bfcbd6',2)
 return im

creators={'golden_foot_v2':golden_foot,'bell_bomb':bell_bomb,'frog_mine':frog_mine,'moon_rocket':moon_rocket,'ban_hammer':ban_hammer,'pep_rain':pep_rain,'doge_flyer':doge_flyer,'silver_donkey':silver_donkey}
images={k:save64(k,f()) for k,f in creators.items()}
# smooth-free checker panel icon overview
font=ImageFont.load_default()
board=Image.new('RGB',(1130,655),'#101d30');d=ImageDraw.Draw(board)
d.rectangle((0,0,1129,62),fill='#1b3190',outline='#819ddb',width=3)
d.text((27,20),'FROGAGEDDON 2.0  //  ARSENAL ART  //  PHASE 1',font=font,fill='#fff8d5',stroke_width=0)
labels=[('golden_foot_v2','MEGA GOLDEN FOOT'),('bell_bomb','BELL BOMB'),('frog_mine','FROG MINE'),('moon_rocket','MOON ROCKET'),('ban_hammer','BAN HAMMER'),('pep_rain','PEP RAIN'),('doge_flyer','DOGE FLYER'),('silver_donkey','SILVER DONKEY')]
for i,(name,label) in enumerate(labels):
 x=25+(i%4)*275;y=85+(i//4)*270
 d.rectangle((x,y,x+250,y+244),fill='#263954',outline='#819cb1',width=3)
 d.rectangle((x+4,y+4,x+246,y+34),fill='#1b3190')
 d.text((x+16,y+14),label,font=font,fill=WHITE)
 d.rectangle((x+49,y+46,x+201,y+198),fill='#16283d',outline='#697f9d',width=2)
 board.paste(images[name],(x+61,y+58),images[name])
 d.text((x+78,y+212),'128x128 PNG',font=font,fill='#c9d8e3')
board.save(root/'previews'/'arsenal_8_icons.png')

# A technical small 64px comparison against very common icons on a simulated dark arsenal tile
menu=Image.new('RGB',(1000,280),'#0b1629');md=ImageDraw.Draw(menu)
md.text((20,16),'HUD TEST: pixel icons at 64 px',font=font,fill=WHITE)
for i,(name,label) in enumerate(labels):
 x=20+(i%8)*122;md.rectangle((x,52,x+110,177),fill='#1a2a42',outline='#909ca9',width=2)
 im=Image.open(root/'hud_64'/f'{name}.png');menu.paste(im,(x+23,69),im)
 md.text((x+8,149),name[:17],font=font,fill='#ebd793')
md.text((20,225),'Concept weapons: separate art assets. No engine parameters are modified.',font=font,fill='#9ab4cb')
menu.save(root/'previews'/'hud_64px.png')

# effects sprites for the first three weapons, tiny clean pixel sprites

def emit_effect_frames(name,fn,count=6):
 frames=[]
 for t in range(count):
  im=Image.new('RGBA',(64,64),(0,0,0,0)); dr=ImageDraw.Draw(im)
  fn(dr,t)
  out=im.resize((128,128),Image.Resampling.NEAREST)
  out.save(root/'effects'/f'{name}_{t:02}.png');frames.append(out)
 atlas=Image.new('RGBA',(128*count,128),(0,0,0,0))
 for t,f in enumerate(frames):atlas.alpha_composite(f,(t*128,0))
 atlas.save(root/'effects'/f'{name}_sheet.png')
 return atlas

def foot_burst(d,t):
 r=[3,8,14,20,14,5][t];x=y=32
 if t<5:
  for a in range(0,360,45):
   aa=math.radians(a); x1=x+math.cos(aa)*r/2;y1=y+math.sin(aa)*r/2;x2=x+math.cos(aa)*(r+8);y2=y+math.sin(aa)*(r+8)
   line(d,[(int(x1),int(y1)),(int(x2),int(y2))],GOLD,3)
  ell(d,(32-r,32-r,32+r,32+r),GOLD,INK,2)
  if r >= 5: ell(d,(32-r+4,32-r+4,32+r-4,32+r-4),HIGHLIGHT,outline=None)
 if t>=3:
  for ix in range(5):
   xx=10+ix*9; yy=51+(ix%2)*2
   d.rectangle((xx,yy,xx+3,yy+3),fill=BROWN)

def bell_ring(d,t):
 # a bell and a ringing sonic ring on bounce
 cx=32; cy=34
 ell(d,(22,19,42,44),GOLD,INK,2);poly(d,[(20,40),(44,40),(47,47),(17,47)],GOLD_MID,INK,2)
 if t:
  s=7+t*3
  d.arc((cx-s,cy-s,cx+s,cy+s),45,135,fill=HIGHLIGHT,width=2)
  d.arc((cx-s,cy-s,cx+s,cy+s),225,315,fill=HIGHLIGHT,width=2)
 if t>=3:sparkle(d,53,10)

def mine_blink(d,t):
 ell(d,(11,34,53,53),PEPE_DARK,INK,2);ell(d,(15,31,49,49),PEPE,INK,2)
 ell(d,(19,27,29,37),WHITE,INK,2);ell(d,(35,27,45,37),WHITE,INK,2)
 d.rectangle((24,32,26,34),fill=INK);d.rectangle((39,32,41,34),fill=INK)
 color=RED if t%2==0 else ORANGE
 d.rectangle((30,14,34,29),fill=STEEL)
 ell(d,(26,8,38,20),color,INK,2)
 if t>=4:sparkle(d,47,10,RED,5)

sheets={'golden_foot_impact':emit_effect_frames('golden_foot_impact',foot_burst), 'bell_bounce':emit_effect_frames('bell_bounce',bell_ring),'frog_mine_arm':emit_effect_frames('frog_mine_arm',mine_blink)}
# metadata validations
stats=[]
for k in creators:
 im=Image.open(root/'icons_128'/f'{k}.png').convert('RGBA');colors=im.getcolors(20000)
 # validate 2x2 internal grid of source zoom2
 pix=im.load()
 assert all(pix[x,y]==pix[x+1,y]==pix[x,y+1]==pix[x+1,y+1] for y in range(0,128,2) for x in range(0,128,2))
 assert colors is not None and len(colors)<=64,(k,len(colors))
 assert any(p[3]==0 for p in im.getdata())
 stats.append({'id':k,'pixels':[128,128],'colors_rgba':len(colors),'alpha':True,'grid':'2x2','hud_size':[64,64]})
(root/'docs'/'ASSET_VALIDATION.json').write_text(json.dumps({'assets':stats,'effects':list(sheets),'status':'art prototypes; not integrated'},indent=2),encoding='utf8')

# optional map silhouette mockups based on game W,H, same thematic colors
import random
for name in ['moon_base','pond_of_doom']:
 W,H=1200,600
 sample=Image.new('RGB',(W,H),(25,40,70) if name=='moon_base' else (76,144,143));d=ImageDraw.Draw(sample)
 random.seed(6 if name=='moon_base' else 15)
 if name=='moon_base':
  for x in range(0,W,200):
   for y in range(0,280,100): d.point((x+(x*7)%199,y+(x*11)%99),fill='#e8e8ec')
  d.ellipse((920,70,1080,230),fill='#ced2d9',outline='#949dad',width=5)
  ground='#666a85';surface='#a6a6ba'
  coords=[(0,475),(100,472),(220,445),(310,405),(420,448),(535,520),(650,492),(755,404),(865,378),(920,420),(1040,455),(1200,485)]
 else:
  d.ellipse((970,75,1050,155),fill='#ebedc5')
  ground='#4d543f';surface='#73a04e'
  coords=[(0,480),(95,450),(215,470),(345,385),(455,405),(580,505),(705,490),(815,365),(935,385),(1045,450),(1200,480)]
 poly_pts=coords+[(1200,599),(0,599)];d.polygon(poly_pts,fill=ground)
 d.line(coords,fill=surface,width=11)
 # caves/craters for actual expected terrain geometry
 for x,y,rx,ry in ([(290,465,44,30),(820,474,46,28)] if name=='moon_base' else [(415,492,42,25),(795,460,37,31)]):d.ellipse((x-rx,y-ry,x+rx,y+ry),fill=(25,40,70) if name=='moon_base' else (76,144,143))
 d.rectangle((0,562,1199,599),fill='#234a73' if name=='moon_base' else '#2c85a5')
 for i in range(5):
  xx=[100,310,510,790,1010][i];yy=coords[min(range(len(coords)),key=lambda j:abs(coords[j][0]-xx))][1]-45
  if name=='moon_base':
   d.rectangle((xx,yy,xx+45,yy+36),fill='#9aaac4',outline='#18263d',width=4)
   d.ellipse((xx+12,yy-10,xx+33,yy+11),fill='#dfe9f5',outline='#18263d',width=3)
  else:
   d.line([(xx+25,yy+16),(xx+25,yy+50)],fill='#654c2d',width=5)
   d.ellipse((xx+8,yy,xx+40,yy+22),fill='#6da348',outline='#295a3f',width=4)
 d.text((30,25),('MOON BASE' if name=='moon_base' else 'POND OF DOOM')+' // ART & TERRAIN CONCEPT (NOT COLLISION MASK)',font=font,fill=WHITE)
 sample.resize((960,480)).save(root/'previews'/f'{name}_terrain_concept.png')

# save source art generation script copy later
(root/'sources'/'make_icons.py').write_text(Path(__file__).read_text(encoding='utf8'),encoding='utf8')
print('DONE',root)
